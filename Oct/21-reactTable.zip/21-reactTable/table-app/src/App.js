import React, { Component } from 'react';
import './App.css';
import SearchResult from './Components/SearchResult'

export default class App extends Component {
  
  render() {
    return (
      <div className="App">
        <h1>react table fragments</h1>
        <input id="tableSearch"/>
       <button>Search</button>
        <table>
          <tbody>
            <SearchResult/>
          </tbody>
        </table>
      </div>
    );
  }

}

